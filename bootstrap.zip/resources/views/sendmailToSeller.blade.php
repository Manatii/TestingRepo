<html>
<head></head>
<body >

<p>
{{$msg}}
</p>
<hr>
<p>
 {{$name}} - {{$phonenumber}}
</p>

</body>
</html>