</!DOCTYPE html>
<html>
<head>
	@yield('header')
</head>
<body>

</body>
</html>