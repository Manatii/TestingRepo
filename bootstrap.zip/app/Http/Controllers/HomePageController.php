<?php

namespace App\Http\Controllers;

use App\Catagory;
use App\Locations;
use App\Provinces;
use App\UserAds;
use DB;
use Illuminate\Http\Request;

class HomePageController extends Controller
{
    public function displaycatagories(){
    	$categories = DB::table('categories')->get();
    	$subCategories = DB::table('subcategory')
            ->get();

        $sponsoredAds = UserAds::where('featured', 'Sponsored Ads Gallery')->get();
    	$locations = Locations::where('province','Western Cape')->get();
    	$adsPerCategory = $this->countAdsPerCatagory($categories);
    	
    	$provinces = Provinces::All();
    	return view('main')->with('categories', $categories)->with('locations', $locations)->with('provinces', $provinces)->with('subCategories', $subCategories)->with('sponsoredAds', $sponsoredAds)->with('adsPerCategory', $adsPerCategory);
    }

      public function countAdsPerCatagory($categories){
        $adsPerCategory = array();
        foreach($categories as $category){
            $category = $category->category;


            $adsPerCat = DB::table('kasiads')
            ->where('main_catagory','like', "%".$category."%")
             ->where('approved',1)
             ->get();
               
            $countCategories = $adsPerCat->count();
            array_push($adsPerCategory, $countCategories);
        }

        return $adsPerCategory;
    }


}
