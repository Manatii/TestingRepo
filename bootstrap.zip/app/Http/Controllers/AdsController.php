<?php

namespace App\Http\Controllers;

use App\ads;
use App\UserAds;
use App\Locations;
use App\SubCategories;
use DB;
use Carbon\Carbon;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;

class AdsController extends Controller
{
	
    
	public function home(){
		$ads = ads::all();
    	return view('home', ['ads' => $ads]);
	}

    public function displayAllAds(){
    	$ads = DB::table('kasiads')
         ->where('approved',1)->get();
    	$catagories = DB::table('catagories')->get();
    	return view('ads', ['ads' => $ads], ['catagories'=>$catagories]);
    }
    public function getLocations($province){

        $ads = DB::table('locations')
        ->where('province', $province)->orderBy('township', 'asc')->get();
    
        return json_encode($ads);
    }
    public function getMainCategories(){

        $main_categories = DB::table('categories')->get();
    
        return json_encode($main_categories);
    }
	public function displayAdsByLocAndItem(){
	    $location = Input::get('city');
		$searchItem = Input::get('searchItem');
	
        $searchValues = preg_split('/\s+/', $searchItem, -1, PREG_SPLIT_NO_EMPTY); 

        $no_ads_message = "";

        $ads = userAds::where(function ($q) use ($searchValues) {
          foreach ($searchValues as $value) {
            $q->orWhere('keywords', 'like', "%{$value}%");
          }
        })->where('province','like', $location)
          ->orWhere('township', 'like',$location)
          ->where('approved',1)
            //->toSql();
          ->Paginate();

        if(count($ads) < 1){
            $no_ads_message = "Sorry, but we didn't find any ads that match your search criteria, don't panic this website is new.";
        }

        $nuImages  = $this->countNuImages($ads);

      

        //get province
         $province = DB::table('locations')
                        ->where('province', $location)->first();

         if(count($province) > 0){

            $province = $province->province;
         }
        




         if(count($province) < 1 ){
             $prov =  DB::table('locations')
                        ->where('township', $location)->get();
                      
            foreach ($prov as $provnce) {
                $province = $provnce->province;
            }
         }

         if($province == null){
            $province = 'Western Cape';
            $locations = DB::table('locations')
                     ->where('province', $province)
                     ->get();
         }

         $locations = Locations::where('province','like', $province)
                     ->get(); 


		$catagories = DB::table('catagories')->get();
            $heading = $this->displayHeading($location = $location,$catagory = null,$province = null, $location);

       
    	
        
    	$adsPerTownship = $this->countAdsPerLocation($locations);
    	
		return view('ads', ['ads'=>$ads,'location'=>$location],['searchItem'=>$searchItem,
				'locations'=>$locations, 'adsPerTownship'=>$adsPerTownship, 'heading'=>$heading,'nuImages'=>$nuImages, 'no_ads_message'=>$no_ads_message]);


	}

     public function displayAdsByCat($category, $province){
        $category = str_replace("-", " ", $category);
        $province = str_replace("-", " ", $province);
        $category = str_replace("and", "&", $category);
        
        $catagories = DB::table('catagories')->get();
        $locations = DB::table('locations')->where('province',$province)->get();
        $adsPerTownship = $this->countAdsPerLocation($locations);
       


        $heading = $this->displayHeading($location=null,$category,$province = null,$township=null);

        $no_ads_message = "";
        $ads = userAds::where('catagory','like', $category)
                        ->where('approved',1)
                        ->Paginate(11);
            //dd($ads);
        if(count($ads) < 1){
            $no_ads_message = "Sorry, but there are currently no ads under this category. don't panic, this website is new";
        }

        $nuImages  = $this->countNuImages($ads);
            
        return view('ads', ['ads' => $ads,'locations'=>$locations, 'adsPerTownship'=>$adsPerTownship, 'no_ads_message'=>$no_ads_message,
                'heading'=>$heading,'nuImages'=>$nuImages, 'no_ads_message'=>$no_ads_message]);




    }


    public function displayAdsByMainCategory($main_catagory, Request $r){
    
        $main_catagory = str_replace("-", " ", $main_catagory); 

        $categories = DB::table('subcategory')->
        where('category_id',$main_catagory)->get();
        $locations = DB::table('locations')->get();
        $adsPerTownship = $this->countAdsPerLocation($locations);
        $province = Input::get('searchItem');        

        $categories = $this->Categories();
        $subCategories = $this->subCategories($categories);
        $catagories = DB::table('catagories')->get();
             

        $heading = $this->displayHeading($location=null,$main_catagory,$province = null,$township=null);
           
        $no_ads_message  = "";
        $ads = userAds::where('main_catagory','like', $main_catagory)
                        ->where('approved',1)
                        ->Paginate(11);
        if(count($ads) < 1){
            $no_ads_message = "Sorry, but there are currently no ads under this category. don't panic, this website is new";
        }
            
        $nuImages  = $this->countNuImages($ads);
      
        return view('ads', ['ads'=>$ads,'locations'=>$locations, 'adsPerTownship'=>$adsPerTownship, 
               'heading'=>$heading,'nuImages'=>$nuImages,'no_ads_message'=>$no_ads_message]);
        
    }



    public function topAdsAndBargain(){
        $ads = userAds::where('featured', "bagain")
            ->where('approved',1)
            ->orWhere('featured', "agent-ad")
            ->limit(8)
            ->get();

            return $ads;

    }



    public function didplayAdsByItemCatLocProv($searchItem,$loc,$catagory,$province){

          
        
        $searchItem = str_replace("-", " ", $searchItem);
        $township = str_replace("-"," ", $loc);
        $township = str_replace("-", " ", $township);
        $catagory = str_replace("-"," ", $catagory);
        $province = str_replace("-", " ", $province);
      
        $catagory = str_replace('&amp;', '&', $catagory);

        $searchValues = preg_split('/\s+/', $searchItem, -1, PREG_SPLIT_NO_EMPTY); 

        $no_ads_message = "";     

        $ads = userAds::where(function ($q) use ($searchValues) {
          foreach ($searchValues as $value) {
            $q->orWhere('keywords', 'like', "%{$value}%");
          }
        })->where('catagory','like', $catagory)
          ->where('township','like', $township)
          ->where('province','like', $province)
          ->where('approved',1)
            //->toSql();
          ->Paginate();
        if(count($ads) < 1){
            $no_ads_message = "Sorry, but we there are currrently no ".$catagory." in ".ucfirst($township).", don't panic this website is new.";
        }


        $provinces = DB::table('locations')
            ->where('province','like', '%'.$province.'%')
            ->get();

       
        $locations = DB::table('locations')
                        ->where('province', $province)
                        ->get(); 
        $adsPerTownship = $this->countAdsPerLocation($locations);   
 
        $nuImages  = $this->countNuImages($ads);
        $heading = $this->displayHeading($location = null,$catagory,$province,$township);

        return view('ads', ['ads'=>$ads,'province'=>$province],['searchItem'=>$searchItem,
                'locations'=>$locations, 'adsPerTownship'=>$adsPerTownship, 'heading'=>$heading,'nuImages'=>$nuImages, 'no_ads_message'=>$no_ads_message]);
    }

     public function didplayAdsByItemMainCatLocProv($searchItem,$loc,$main_catagory,$province){

        $searchItem = str_replace("-", " ", $searchItem);
        $township = str_replace("-"," ", $loc);
        $township = str_replace("-", " ", $township);
        $main_catagory = str_replace("-"," ", $main_catagory);
        $province = str_replace("-", " ", $province);
      
        $main_catagory = str_replace('&amp;', '&', $main_catagory);

        $searchValues = preg_split('/\s+/', $searchItem, -1, PREG_SPLIT_NO_EMPTY); 

        $no_ads_message = "";     

        $ads = userAds::where(function ($q) use ($searchValues) {
          foreach ($searchValues as $value) {
            $q->orWhere('keywords', 'like', "%{$value}%");
          }
        })->where('main_catagory','like', $main_catagory)
          ->where('township','like', $township)
          ->where('approved',1)
           // ->toSql();
         ->Paginate();
           
        if(count($ads) < 1){
            $no_ads_message = "Sorry, but we there are currrently no ".$main_catagory." in ".ucfirst($township).", don't panic this website is new.";
        }


        $provinces = DB::table('locations')
            ->where('province','like', '%'.$province.'%')
            ->get();

       
        $locations = DB::table('locations')
                        ->where('province', $province)
                        ->get(); 
        $adsPerTownship = $this->countAdsPerLocation($locations);   
 
        $nuImages  = $this->countNuImages($ads);
        $heading = $this->displayHeading($location = null,$main_catagory,$province,$township);

        return view('ads', ['ads'=>$ads,'province'=>$province],['searchItem'=>$searchItem,
                'locations'=>$locations, 'adsPerTownship'=>$adsPerTownship, 'heading'=>$heading,'nuImages'=>$nuImages, 'no_ads_message'=>$no_ads_message]);
    }

	public function didplayAdsByItemCatProv(){

		$catagory = Input::get('category');
        $searchItem = Input::get('searchItem');
		$province = Input::get('prov');

        $searchValues = preg_split('/\s+/', $searchItem, -1, PREG_SPLIT_NO_EMPTY); 
        
        $no_ads_message = "";
        $ads = userAds::where(function ($q) use ($searchValues) {
          foreach ($searchValues as $value) {
            $q->orWhere('keywords', 'like', "%{$value}%");
          }
        })->where('catagory','like', '%'.$catagory.'%')
          ->where('province','like', '%'.$province.'%')
           ->where('approved',1)
            //->toSql();
          ->Paginate();

        if(count($ads) < 1){
            $no_ads_message = "Sorry, but we didn't find any ads that match your search criteria, don't panic this website is new.";
        }
        
        $locations = DB::table('locations')
                         ->where('province',$province)
                         ->get();
    	$adsPerTownship = $this->countAdsPerLocation($locations);
    	$nuImages  = $this->countNuImages($ads);
        $heading = $this->displayHeading($location = null,$catagory,$province,$township=null);
        
        //dd($searchItem."--".$catagory."--".$province);
		return view('ads', ['ads'=>$ads,'province'=>$province],['searchItem'=>$searchItem,'locations'=>$locations, 'adsPerTownship'=>$adsPerTownship, 'heading'=>$heading,'nuImages'=>$nuImages,'province'=>$province, 'no_ads_message'=>$no_ads_message]);
	}

    public function displayAdsSubCategories($category, Request $r){

    	$category = str_replace("-", " ", $category);

    	$locations = DB::table('locations')->get();
    	$adsPerTownship = $this->countAdsPerLocation($locations);
    	$province = Input::get('searchItem');    	

    	$heading = $this->displayHeading($location=null,$category,$province = null,$township=null);      	

        $ads = userAds::where('catagory','like', $category)
                        ->where('approved',1)
			            ->Paginate(11);
		
		$nuImages  = $this->countNuImages($ads);
		$adsPerCatagory = $this->countAdsPerCatagory($catagories);
		
        return view('sub-category', ['ads' => $ads,
				'locations'=>$locations, 'adsPerTownship'=>$adsPerTownship,'heading'=>$heading,'nuImages'=>$nuImages]);

    }

    public function countNuImages($ads){
    	$nuImages = array();
    	foreach($ads as $ad){
    		$adId = $ad->adid;


    		$images = DB::table('images')
			->where('adid', $adId)
			 ->get();
               
       	    $countImages = $images->count();
			array_push($nuImages, $countImages);
    	}

    	return $nuImages;
    }

    public function displayHeading($location,$catagory,$province, $township){
    	if($location != null && $province==Null && $catagory == null ){
    		return "<a href='#' class='current'><span>All ads in</span></a><span class='cityName'>". $location."</span> <a href='#selectRegion' id='dropdownMenu1'
                                                                                data-toggle='modal'> <span
                                            class='caret'></span> </a>";
    	}
    	else if($location == null && $catagory != null && $province!=null && $township==null ){
    		return "<a href='#' class='current'><span>".ucfirst($catagory)." in</span></a><span class='cityName'>". $province ."</span> <a href='#selectRegion' id='dropdownMenu1'
                                                                                data-toggle='modal'> <span
                                            class='caret'></span> </a>";
    	}
        else if($location == null && $catagory != null && $province!=null && $township !=null){
            return "<a href='#' class='current'><span>".ucfirst($catagory) ." in</span></a><span class='cityName'>".ucfirst($township)."</span> <a href='#selectRegion' id='dropdownMenu1'
                                                                                data-toggle='modal'> <span
                                            class='caret'></span> </a>";
        }
        else if($catagory != null && $location == null && $province == null && $township == null){
            return "<a href='#' class='current'><span>". ucfirst($catagory ) ." in</span></a><span class='cityName'>All provinces</span> <a href='#selectRegion' id='dropdownMenu1'
                                                                                data-toggle='modal'> <span
                                            class='caret'></span> </a>";
        }
    	else{
    		return "<a href='#' class='current'><span>Ads in</span></a><span class='cityName'> Western Cape</span>";
    	}


    }

     public function Categories(){
        $categories = DB::table('categories')->get();

       
        return $categories;

    }

    public function displayAdsbyLoc($location){

    	$location = str_replace("-", " ", $location);
       	
    	$locations = DB::table('locations')->where('province',$location)->get();


        if(count($locations)< 1){

            $locations = DB::table('locations')->where('township',$location)->first();
            $province = $locations->province;
            $locations = DB::table('locations')->where('province',$province)->get();
        }


    	$adsPerTownship = $this->countAdsPerLocation($locations);

    	$heading = $this->displayHeading($location,$catagory = null,$province = null, $township=null);
        
        $no_ads_message = "";
    	$ads = userAds::where('township','like', $location)
                          ->where('approved',1)
			              ->Paginate(11);

		if(count($ads) < 1){
            $no_ads_message = 'Sorry but there are currently no ads in '.ucfirst($location). ". Don't panic this website is new";
        }
       

		$nuImages  = $this->countNuImages($ads);
        return view('ads', ['ads' => $ads,
				'locations'=>$locations, 'adsPerTownship'=>$adsPerTownship,'heading'=>$heading,'nuImages'=>$nuImages, 'no_ads_message'=>$no_ads_message]);
    }

    public function countAdsPerCatagory($catagories){
    	$adsPerCatagory = array();
    	foreach($catagories as $catagory){
    		$catagory = $catagory->catagory;


    		$adsPerCat = DB::table('kasiads')
			->where('keywords','like', "%".$catagory."%")
             ->where('approved',1)
			 ->get();
               
       	    $countCatagories = $adsPerCat->count();
			array_push($adsPerCatagory, $countCatagories);
    	}

    	return $adsPerCatagory;
    }

    public function countAdsPerLocation($locations){
    	$adsPerTownship = array();
    	foreach($locations as $location){
    		$location = $location->township;
    		$adsPerLoc = DB::table('kasiads')
			->where('township','like', "%".$location."%")
			 ->get();
               
       	    $countLocations = $adsPerLoc->count();
			array_push($adsPerTownship, $countLocations);
    	}

    	return $adsPerTownship;
    }

   

    public function subCategories(){
       $subCategories = DB::table('subcategory')->get();
       return $subCategories;
    }

    public function getSubCategoriesById($category_id){
        
        $subCategories = SubCategories::where('category_id',$category_id)->get();
        foreach($subCategories as $subCat){

            $adsPerSubCat = UserAds::where('catagory',$subCat->subcategory_name)->get();
            $subCat->nu_ads = count($adsPerSubCat);
        }
        return json_encode($subCategories);
    }

	public function displayAds(Request $request){

        $no_ads_message = "";        
		$ads = userAds::where('approved',1)
                       ->Paginate(16); 

		$locations = DB::table('locations')
                        ->where('province', 'Western Cape')
                        ->get();

        $adsPerTownship = $this->countAdsPerLocation($locations);

        $nuImages  = $this->countNuImages($ads);
        $heading = $this->displayHeading($location=null,$catagory = null,$province = "All Provinces", $township = null);

    	return view('ads', ['ads' => $ads,'locations'=>$locations,'adsPerTownship'=>$adsPerTownship, 'nuImages'=>$nuImages,'heading'=>$heading,'no_ads_message'=>$no_ads_message]);
	}


   
}
