<?php

namespace App\Http\Controllers;
use DB;
use App\User;
use App\UserAds;

use Illuminate\Http\Request;

class adsDetailsController extends Controller
{
    public function displayAdsDetails($adId){
    	$adDetails = UserAds::where('adid','like', '%'.$adId.'%')
		 ->get();

		$images = DB::table('images')
			->where('adid',$adId)
			->get();

		$user_id = " ";

		foreach($adDetails as $detail){
			$user_id = $detail->user_id;
		}
		
		$userDetails = User::where('id', $user_id)->get();


		 return view('adsdetails',['adDetails'=>$adDetails, 'images'=>$images, 'userDetails'=>$userDetails]);
    }
}
