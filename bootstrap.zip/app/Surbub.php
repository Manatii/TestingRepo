<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Surbub extends Model
{
    //
      protected $table = 'surbubs';
}
