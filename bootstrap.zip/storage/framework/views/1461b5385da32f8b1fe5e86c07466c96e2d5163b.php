<html>
<head></head>
<body >
<p>
 Ad title : <?php echo e($title); ?> </p>
 <p> Category : <?php echo e($category); ?> </p>
 <p> Seller's name: <?php echo e($userName); ?> </p>
 <p> Seller email address: <?php echo e($email); ?> </p>
 <p> Seller's phone number: <?php echo e($phonenumber); ?></p>
 <?php if($promotionPlan != null): ?>
 <p> Promotion plan: <?php echo e($promotionPlan); ?>	</p>
 <?php endif; ?>
 <?php if($pin != null): ?>
 <p> Pin: <?php echo e($pin); ?> </p>
 <?php endif; ?>

<p>Description: </br>
<?php echo e($msg); ?>

</p>
<hr>


</body>
</html>