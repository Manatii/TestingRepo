<?php $__env->startSection('content'); ?>
<div class="main-container">
        <div class="container">
            <div class="row">
                <div class="col-sm-3 page-sidebar">
                    <aside>
                        <div class="inner-box">
                            <div class="user-panel-sidebar">
                                <div class="collapse-box">
                                    <h5 class="collapse-title no-border"> My Classified <a class="pull-right"
                                                                                           data-toggle="collapse"
                                                                                           href="#MyClassified"><i
                                            class="fa fa-angle-down"></i></a></h5>

                                    <div id="MyClassified" class="panel-collapse collapse in">
                                        <ul class="acc-list">
                                            <li><a href="<?php echo e(url('/account')); ?>"><i class="icon-home"></i> Personal Home </a>
                                            </li>

                                        </ul>
                                    </div>
                                </div>
                                <!-- /.collapse-box  -->
                                <div class="collapse-box">
                                    <h5 class="collapse-title"> My Ads <a class="pull-right" data-toggle="collapse"
                                                                          href="#MyAds"><i class="fa fa-angle-down"></i></a>
                                    </h5>

                                    <div id="MyAds" class="panel-collapse collapse in">
                                        <ul class="acc-list">
                                            <li><a href="<?php echo e(url('/account-myads')); ?>"><i class="icon-docs"></i> My ads <span
                                                    class="badge"><?php echo count($userAds); ?></span> </a></li>
                                            <li class="active"><a href="<?php echo e(url('/account-favourite-ads')); ?>"><i
                                                    class="icon-heart"></i> Favourite ads <span class="badge"><?php echo count($fav_Ads); ?></span>
                                            </a></li>
                                            <li><a href=""><i class="icon-star-circled"></i>
                                                Saved search <span class="badge">0</span> </a></li>
                                            <li><a href=""><i class="icon-folder-close"></i>
                                                Archived ads <span class="badge">0</span></a></li>
                                            <li><a href="<?php echo e(url('/account-pending-approval-ads')); ?>"><i
                                                    class="icon-hourglass"></i> Pending approval <span
                                                    class="badge"><?php echo count($unApprovedAds) ?></span></a></li>

                                        </ul>
                                    </div>
                                </div>

                                <!-- /.collapse-box  -->
                                <div class="collapse-box">
                                    <h5 class="collapse-title"> Terminate Account <a class="pull-right"
                                                                                     data-toggle="collapse"
                                                                                     href="#TerminateAccount"><i
                                            class="fa fa-angle-down"></i></a></h5>

                                    <div id="TerminateAccount" class="panel-collapse collapse in">
                                        <ul class="acc-list">
                                            <li><a href=""><i class="icon-cancel-circled "></i> Close
                                                account </a></li>
                                        </ul>
                                    </div>
                                </div>
                                <!-- /.collapse-box  -->
                            </div>
                        </div>
                        <!-- /.inner-box  -->

                    </aside>
                </div>
                <!--/.page-sidebar-->

                <div class="col-sm-9 page-content">
                    <div class="inner-box">
                        <h2 class="title-2"><i class="icon-heart-1"></i> Favourite ads </h2>

                        <div class="table-responsive">
                            <div class="table-action">
                                <label for="checkAll">
                                    <input type="checkbox" id="checkAll">
                                    Select: All | <a href="#" class="btn btn-xs btn-danger">Delete <i
                                        class="glyphicon glyphicon-remove "></i></a> </label>

                                <div class="table-search pull-right col-xs-7">
                                    <div class="form-group">
                                        <label class="col-xs-5 control-label text-right">Search <br>
                                            <a title="clear filter" class="clear-filter" href="#clear">[clear]</a>
                                        </label>

                                        <div class="col-xs-7 searchpan">
                                            <input type="text" class="form-control" id="filter">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <table id="addManageTable"
                                   class="table table-striped table-bordered add-manage-table table demo"
                                   data-filter="#filter" data-filter-text-only="true">
                                <thead>
                                <tr>
                                    <th data-type="numeric" data-sort-initial="true"></th>
                                    <th> Photo</th>
                                    <th data-sort-ignore="true"> Adds Details</th>
                                    <th data-type="numeric"> Price</th>
                                    <th> Option</th>
                                </tr>
                                </thead>
                                <tbody>

                                <?php $__currentLoopData = $fav_Ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fav_ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td style="width:2%" class="add-img-selector">
                                        <div class="checkbox">
                                            <label>
                                                <input type="checkbox">
                                            </label>
                                        </div>
                                    </td>
                                    <td style="width:14%" class="add-img-td"><a href="<?php echo asset('/ad-details/');?><?php echo "/".$fav_ad->ad_id; ?>"><img
                                            class="thumbnail  img-responsive"
                                            src="<?php echo asset('assets/thumbnail.php?adid=')?><?php echo $fav_ad->ad_id;?>"
                                            alt="img"></a></td>
                                    <td style="width:58%" class="ads-details-td">
                                        <div>
                                            <p><strong> <a href="<?php echo asset('/ad-details/');?><?php echo "/".$fav_ad->ad_id; ?>" title="<?php echo e($fav_ad->title); ?>"><?php echo e($fav_ad->title); ?></a> </strong></p>

                                            <p><strong> Posted On </strong>:
                                               <?php echo e($fav_ad->created_at); ?> </p>

                                            <p><strong>Visitors </strong>: 221 <strong>Located In:</strong> <?php echo e($fav_ad->township); ?>

                                            </p>
                                        </div>
                                    </td>
                                    <td style="width:16%" class="price-td">
                                        <div><strong>R<?php echo e($fav_ad->price); ?></strong></div>
                                    </td>
                                    <td style="width:10%" class="action-td">
                                        <div>
                                            <p><a class="btn btn-info btn-xs"> <i class="fa fa-mail-forward"></i> Share
                                            </a></p>

                                            <p><a class="btn btn-danger btn-xs delete" id="<?php echo e($fav_ad->ad_id); ?>"> <i class=" fa fa-trash"></i> Delete
                                            </a></p>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                                </tbody>
                            </table>
                        </div>
                        <!--/.row-box End-->

                    </div>
                </div>
                <!--/.page-content-->
            </div>
            <!--/.row-->
        </div>
        <!--/.container-->
    </div>
    <!-- /.main-container -->
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(url('assets/js/jquery/jquery-latest.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bootstrap/js/bootstrap.min.js')); ?> "></script>

<!-- include checkRadio plugin //Custom check & Radio  -->
<script type="<?php echo e(asset('text/javascript" src="assets/js/icheck.min.js')); ?>"></script>


<!-- include carousel slider plugin  -->
<script src="<?php echo e(asset('assets/js/owl.carousel.min.js')); ?>"></script>

<!-- include equal height plugin  -->
<script src="<?php echo e(asset('assets/js/jquery.matchHeight-min.js')); ?>"></script>

<!-- include jquery list shorting plugin plugin  -->
<script src="<?php echo e(asset('assets/js/hideMaxListItem.js')); ?>"></script>

<!-- include footable   -->

<script src="<?php echo e(asset( 'assets/js/footable.js?v=2-0-1" type="text/javascript')); ?>"></script>
<script src="<?php echo e(asset('assets/js/footable.filter.js?v=2-0-1" type="text/javascript')); ?>"> </script>

<script type="text/javascript">
    $(function () {
        $('#addManageTable').footable().bind('footable_filtering', function (e) {
            var selected = $('.filter-status').find(':selected').text();
            if (selected && selected.length > 0) {
                e.filter += (e.filter && e.filter.length > 0) ? ' ' + selected : selected;
                e.clear = !e.filter;
            }
        });

        $('.clear-filter').click(function (e) {
            e.preventDefault();
            $('.filter-status').val('');
            $('table.demo').trigger('footable_clear_filter');
        });

    });
</script>
<!-- include custom script for ads table [select all checkbox]  -->
<script>

    function checkAll(bx) {
        var chkinput = document.getElementsByTagName('input');
        for (var i = 0; i < chkinput.length; i++) {
            if (chkinput[i].type == 'checkbox') {
                chkinput[i].checked = bx.checked;
            }
        }
    }


    $('.delete').click(function(){
        var r = confirm("Are you sure you want to delete this ad?");
        var id = $(this).attr('id') 

          if (r == true) {
            path = "<?php echo e(url('deleteFavAd')); ?>"+"/"+id;
             $.ajax({
                url: path,
                type: 'GET',
                data: {id:id},
                success:function(data){
                       location.reload();
                  
                        console.log(data);
                     
                   
               }
            });
         }
    });

</script>

<!-- include jquery.fs plugin for custom scroller and selecter  -->
<script src="<?php echo e(asset('assets/plugins/jquery.fs.scroller/jquery.fs.scroller.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/jquery.fs.selecter/jquery.fs.selecter.js')); ?>"></script>
<!-- include custom script for site  -->
<script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
</script>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>