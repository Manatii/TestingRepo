<html>
<head></head>
<body >

<p>
<?php echo e($msg); ?>

</p>
<hr>
<p>
 <?php echo e($name); ?> - <?php echo e($phonenumber); ?>

</p>

</body>
</html>