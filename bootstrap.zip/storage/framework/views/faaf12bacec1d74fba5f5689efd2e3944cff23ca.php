<select class="form-control" name="category" id="search-category">
    <?php $i = 0; ?>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($cat->category); ?>" style="background-color:#E9E9E9;font-weight:bold;" disabled="disabled" >
        - <?php echo e($cat->category); ?> -
        </option>
        <?php $__currentLoopData = $subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($subCat->category_id == $cat->cat_id): ?>
                <option value="<?php echo e($subCat->subcategory_name); ?>">    
                <?php echo e($subCat->subcategory_name); ?></option>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>