<div class="inner-box relative" style="margin-top:20px;">
    <h2 class="title-2">Sponsored Ads
        <a id="nextItem" class="link  pull-right carousel-nav"> <i class="icon-right-open-big"></i></a>
        <a id="prevItem" class="link pull-right carousel-nav"> <i class="icon-left-open-big"></i>
        </a>
    </h2>
    <div class="row">
        <div class="col-lg-12">
            <div class="no-margin item-carousel owl-carousel owl-theme">
                <?php $__currentLoopData = $sponsoredAds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sponsored): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item">
                        <a href="<?php echo asset('/ad-details/');?><?php echo "/".$sponsored->adid; ?> ">
                        <span class="item-carousel-thumb">
                            <img class="img-responsive" src="<?php echo asset('assets/thumbnail.php?adid=')?><?php echo $sponsored->adid; ?>">
                        </span>
                        <span class="item-name"> <?php echo e($sponsored->title); ?>  </span>
                        <span class="price">R<?php echo e($sponsored->price); ?> </span>
                        </a>
                    </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>