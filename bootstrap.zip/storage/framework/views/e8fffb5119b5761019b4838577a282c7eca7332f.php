 <div class="categories-list list-filter">
   <h5 class="list-title"><strong><a href="#"> All Categories</a></strong></h5>
    <ul class="browse-list list-unstyled long-list">
      <?php $i =0; ?>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                 
            <li id = '<?php echo e($category->cat_id); ?>' title = '<?php echo e($category->category); ?>' style="cursor:pointer;padding: 2px 15px 2px 5px;"><?php echo e($category->category); ?> <span class="count">(<?php echo e($adsPerCategory[$i]); ?>)</span>
            </li>

            <?php   $i++ ?>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>