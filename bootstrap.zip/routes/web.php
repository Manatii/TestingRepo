<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::group(['middleware' => ['web']], function (){
 
  
});

Route::any('/ads', [
	'uses' => 'AdsController@displayAds',
]);

Route::any('/', [
	'uses' => 'HomePageController@displaycatagories',
]);

Route::any('/ads/loc-search-item', [
	'uses' => 'AdsController@displayAdsByLocAndItem',
]);

//get locations by province
Route::any('/locations/{province}', [
	'uses' => 'AdsController@getLocations',
]);

//get subcategory by id
Route::any('/sub-categories/{subcatid}', [
	'uses' => 'AdsController@getSubCategoriesById',
]);

Route::get('/main-categories', [
	'uses' => 'AdsController@getMainCategories',
]);

Route::any('/ads/search-item-cat-province', array('as'=>'search-item-cat-province','uses'=>'AdsController@didplayAdsByItemCatProv'));

Route::get('/search-item-loc-cat-prov/{item}/{location}/{catagory}/{province}', [
	'uses' => 'AdsController@didplayAdsByItemCatLocProv',
]);

Route::get('/search-item-loc-main-cat-prov/{item}/{location}/{catagory}/{province}', [
	'uses' => 'AdsController@didplayAdsByItemMainCatLocProv',
]);

Route::any('/ads/catagory/{catagory?}/{province?}', [
	'province' => null,
	'uses' => 'AdsController@displayAdsByCat',

	
]);

Route::get('/ads/main-category/{maincategory?}', [
	'uses' => 'AdsController@displayAdsByMainCategory',
]);
Route::get('/ads/location/{location?}', [
	'uses' => 'AdsController@displayAdsByLoc',
]);

Route::any('/ads/', [
	'uses' => 'AdsController@displayAds',
]);

Route::get('/ad-details/{adid?}', [
	'uses' =>'adsDetailsController@displayAdsDetails',
]);

Route::get('/postfreead',array('as'=>'postfreead','uses'=>'postAdsConroller@newAd'));


Route::get('/autocomplete',array('as'=>'autoComplete','uses'=>'postAdsConroller@autoComplete'));

Route::get('/autoCompleteTownship',array('as'=>'autoCompleteTownship','uses'=>'postAdsConroller@autoCompleteTownship'));

Route::post('/postfreead', [
	'uses'	=>'postAdsConroller@postAd',
]);

Route::get('/posting-successful', function(){
	return view('posting-successful');
});
Route::get('/adsdetails3', function(){
	return view('adsdetails3');
});

Route::post('/createuser',array('as'=>'createuser','uses'=>'Auth\RegisterController@create')

);

Route::get('/signup',function(){


  return view('Auth\signup');

});



Route::get('/posting-success', function(){
	return view('posting-success');
});

Route::get('sub-category-sub-location', function(){
	return view('sub-category-sub-location');
});

Route::get('faq', function(){
	return view('faq');
});

Route::get('contact', function(){
	return view('contact');
});



Route::get('terms-and-conditions', function(){
	return view('terms-and-conditions');
});

Route::get('about', function(){
	return view('about');
});

Route::get('logout', 'Auth\SocialAuthController@getLogout');

Auth::routes();

Route::get('/home', 'HomeController@index');



Auth::routes();

Route::get('/redirect', 'Auth\SocialAuthController@redirect');

Route::get('/callback', 'Auth\SocialAuthController@callback');

Route::group(['middleware' =>[ 'web']], function () {
    Route::get('/redirect', 'Auth\SocialAuthController@redirect');

Route::get('/callback', 'Auth\SocialAuthController@callback');
});

Route::post('sendmail', 'SendEmailController@sendEmail');

Route::get('/account', 'AccountController@displayAccount');
Route::get('/savead/{adid}', 'AccountController@saveAd');
Route::get('/account-myads', 'AccountController@displayUserAds');
Route::get('/deletead/{adid}','AccountController@deleteAd');
Route::get('/account-favourite-ads','AccountController@displayFavouriteAds');
Route::get('/edit-ad/{adid}/{userid}','AccountController@editAd');
Route::post('/edit-ad/{adid}/{userid}','AccountController@updateAd');
Route::post('delete-image/{id}','AccountController@deleteImage');
Route::get('/deleteFavAd/{adid}','AccountController@deleteFavAd');
Route::get('/delete-unapproved-ad/{adid}','AccountController@deleteUnApprovedAd');
Route::get('/update-user-details/{name}/{surname}/{phonenumber}','AccountController@updateUserDetails');



Route::get('/account-pending-approval-ads', 'AccountController@displayPendingAds');












	
   

