# jQuery.SimpleSelect

jQuery.simpleselect makes every `<select>` 100% customizable using CSS.

Documentation and demos: http://pioul.fr/jquery-simpleselect
