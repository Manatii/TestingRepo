$(document).ready(function() {

	$("#example-select").simpleselect({
		fadingDuration: 500,
		containerMargin: 100,
		displayContainerInside: "document"
	});

});